<?php

return [
    'topics' => [
        'Casino',
        'CBD',
        'Crypto',
        'Dating',
        'Drug',
        'Escorts',
        'Gambling',
        'Growshop',
        'Medication',
        'Politics',
        'Promotional articles',
        'Religion',
        'Sexshop',
        'Sexuality',
        'Tarot and Esotericism',
    ],
];
