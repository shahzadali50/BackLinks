<?php $__env->startSection('title'); ?>
Project | <?php echo e(auth()->user()->role); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
<style>

</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php $__env->startComponent('components.breadcrumb'); ?>
<?php $__env->slot('li_1'); ?>
Wallet
<?php $__env->endSlot(); ?>
<?php $__env->slot('title'); ?>
Add Bill Detail
<?php $__env->endSlot(); ?>
<?php echo $__env->renderComponent(); ?>
<div class="row">
    <div class="col-12 ">
        <div class="card">
            <div class="card-header ">
                <h4>Add credit</h4>

            </div>
            <div class="card-body">


                   <form action="<?php echo e(route('advertiser.credit.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        
                        <div class="col-12 mb-4">
                            <label for="Amount">Amount </label>
                            <div class="input-group">

                                <span class="input-group-text">$</span>
                                <input id="Amount" name="amount" type="number" class="form-control" required>

                            </div>
                            <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class=" mt-1 alert alert-danger alert-dismissible alert-label-icon label-arrow fade show" role="alert">
                                <i class="ri-error-warning-line label-icon"></i><strong><?php echo e($message); ?></strong>
                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>
                        <div class="col-12 mb-4">
                            <!-- Accordions with Plus Icon -->
                            <div class="accordion custom-accordionwithicon-plus" id="accordionWithplusicon">
                                <div class="accordion-item material-shadow">
                                    <h2 class="accordion-header" id="accordionwithplusExample1">
                                        <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#accor_plusExamplecollapse1" aria-expanded="true" aria-controls="accor_plusExamplecollapse1">
                                            Do you have a promotional coupon?
                                        </button>
                                    </h2>
                                    <div id="accor_plusExamplecollapse1" class="accordion-collapse collapse " aria-labelledby="accordionwithplusExample1" data-bs-parent="#accordionWithplusicon">
                                        <div class="accordion-body">
                                            <div class="input-group">

                                                <input name="coupon" type="number" class="form-control" >
                                                <span class="input-group-text" >Apply coupon</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                            <?php $__errorArgs = ['coupon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger alert-dismissible alert-label-icon label-arrow fade show" role="alert">
                                <i class="ri-error-warning-line label-icon"></i><strong><?php echo e($message); ?></strong>
                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>
                        
                        <div class="col-12 ">
                            <label for="Project_Objectives">Select your payment method<span class="text-danger" style="font-size: 16px;">
                                    *</span></label>
                        </div>
                        <div class="col-12 d-flex ">
                            <div class="mb-3 me-4">

                                <input name="payment_method" type="radio" class="btn-check" id="PayPal" value="desktop" <?php echo e(old('track_device')=='desktop' ? 'checked' : ''); ?>>
                                <label class="btn btn-outline-white" for="PayPal">
                                    <div>
                                       <img style="width: 133px; height:133px;" class="img-fluid" src="<?php echo e(URL::asset('build/images/pay-bill/paypal.png')); ?>" alt="not">
                                    </div>
                                   <div>

                                    <strong style="color: black">PayPal</strong>
                                   </div>
                                </label>

                            </div>
                            <div class="mb-3 ms-3">

                                <input name="payment_method" type="radio" class="btn-check" id="Credit_Card" value="desktop" <?php echo e(old('track_device')=='desktop' ? 'checked' : ''); ?>>
                                <label class="btn btn-outline-white" for="Credit_Card">
                                    <div>
                                       <img style="width: 133px; height:133px;" class="img-fluid" src="<?php echo e(URL::asset('build/images/pay-bill/stripe.png')); ?>" alt="not">
                                    </div>
                                   <div>
                                    <strong style="color: black">Credit Card</strong>
                                   </div>
                                </label>

                            </div>
                            <div class="mb-3 ms-3">

                                <input name="payment_method" type="radio" class="btn-check" id="Bank_Transfer" value="desktop" <?php echo e(old('track_device')=='desktop' ? 'checked' : ''); ?>>
                                <label class="btn btn-outline-white" for="Bank_Transfer">
                                    <div>
                                       <img style="width: 133px; height:133px;" class="img-fluid" src="<?php echo e(URL::asset('build/images/pay-bill/bank-transfer-2.png')); ?>" alt="not">
                                    </div>
                                   <div>
                                    <strong style="color: black">Bank Transfer</strong>
                                   </div>
                                </label>

                            </div>
                        </div>
                        <div class="col-12 mt-3">
                            <button type="submit" class="btn btn-primary btn-lg">Save</button>

                                <a href="<?php echo e(route('advertiser.wallet')); ?>" class="btn btn-dark btn-lg ms-2"> <i class="fa fa-arrow-left"></i> back</a>

                        </div>
                    </div>
                   </form>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    $(document).ready(function(){
        <?php if(session('success')): ?>
        Swal.fire({
                title: 'Thank You 👍',
                text: '<?php echo e(session('success')); ?>',
                icon: 'success'
            });
        <?php endif; ?>

    })
</script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\BS.IT_Material\Hidden-logics\laravel\BackLinks\resources\views/advertiser/bill-detail/index.blade.php ENDPATH**/ ?>