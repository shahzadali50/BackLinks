<?php $__env->startSection('title'); ?>
Home |  <?php echo e(auth()->user()->role); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php $__env->startComponent('components.breadcrumb'); ?>
<?php $__env->slot('li_1'); ?>
Advertisers
<?php $__env->endSlot(); ?>
<?php $__env->slot('title'); ?>
Home

<?php $__env->endSlot(); ?>
<?php echo $__env->renderComponent(); ?>
<div class="row">
    <h3>Welcome to <?php echo e(auth()->user()->name); ?></h3>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\BS.IT_Material\Hidden-logics\laravel\BackLinks\resources\views/advertiser/dashboard.blade.php ENDPATH**/ ?>