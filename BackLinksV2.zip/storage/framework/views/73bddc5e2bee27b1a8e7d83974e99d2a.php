<?php $__env->startSection('title'); ?> Home | Admin <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php $__env->startComponent('components.breadcrumb'); ?>
<?php $__env->slot('li_1'); ?>
Admin
<?php $__env->endSlot(); ?>
<?php $__env->slot('title'); ?>
Home
<?php $__env->endSlot(); ?>
<?php echo $__env->renderComponent(); ?>
<div class="col-12">
    <h1>Welcome, <?php echo e(auth()->user()->name); ?></h1>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\BS.IT_Material\Hidden-logics\laravel\BackLinks\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>