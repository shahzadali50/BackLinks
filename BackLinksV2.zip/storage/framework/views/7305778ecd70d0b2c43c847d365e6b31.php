<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" data-topbar="light" data-sidebar-image="none">

    <head>
    <meta charset="utf-8" />
    <title><?php echo $__env->yieldContent('title'); ?>ContentLink</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- App favicon -->
    <link rel="shortcut icon" href="<?php echo e(URL::asset('build/images/favicon.ico')); ?>">
       <?php if (isset($component)) { $__componentOriginale7e538c3076c7cf5dc291c8995a8b28d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale7e538c3076c7cf5dc291c8995a8b28d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.head-css','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('head-css'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale7e538c3076c7cf5dc291c8995a8b28d)): ?>
<?php $attributes = $__attributesOriginale7e538c3076c7cf5dc291c8995a8b28d; ?>
<?php unset($__attributesOriginale7e538c3076c7cf5dc291c8995a8b28d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale7e538c3076c7cf5dc291c8995a8b28d)): ?>
<?php $component = $__componentOriginale7e538c3076c7cf5dc291c8995a8b28d; ?>
<?php unset($__componentOriginale7e538c3076c7cf5dc291c8995a8b28d); ?>
<?php endif; ?>
  </head>

    <?php echo $__env->yieldContent('body'); ?>

    <?php echo $__env->yieldContent('content'); ?>


    <?php if (isset($component)) { $__componentOriginal31cb59423ba1f759026ebe11d6ad323d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal31cb59423ba1f759026ebe11d6ad323d = $attributes; } ?>
<?php $component = App\View\Components\Foot::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('foot'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Foot::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal31cb59423ba1f759026ebe11d6ad323d)): ?>
<?php $attributes = $__attributesOriginal31cb59423ba1f759026ebe11d6ad323d; ?>
<?php unset($__attributesOriginal31cb59423ba1f759026ebe11d6ad323d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal31cb59423ba1f759026ebe11d6ad323d)): ?>
<?php $component = $__componentOriginal31cb59423ba1f759026ebe11d6ad323d; ?>
<?php unset($__componentOriginal31cb59423ba1f759026ebe11d6ad323d); ?>
<?php endif; ?>
    </body>
</html>
<?php /**PATH D:\BS.IT_Material\Hidden-logics\laravel\BackLinks\resources\views/layouts/master-without-nav.blade.php ENDPATH**/ ?>