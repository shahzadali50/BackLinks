<!-- ========== App Menu ========== -->
<div class="app-menu navbar-menu">
    <!-- LOGO -->
    <div class="navbar-brand-box">

        <!-- Dark Logo-->
        <a href="<?php echo e(route('publishers.dashboard')); ?>" class="logo logo-dark">
            <span class="logo-sm">
                <img src="<?php echo e(URL::asset('build/images/logo-sm.png')); ?>" alt="" height="22">


            </span>
            <span class="logo-lg">
                <img src="<?php echo e(URL::asset('build/images/logo-dark.png')); ?>" alt="" height="17">

            </span>
        </a>
        <!-- Light Logo-->
        <a href="<?php echo e(route('dashboard')); ?>" class="logo logo-light">
            <span class="logo-sm">
                <img src="<?php echo e(URL::asset('build/images/logo-sm.png')); ?>" alt="" height="22">
            </span>
            <span class="logo-lg">
               <?php if(auth()->guard()->check()): ?>
                   <?php if(Auth::user()->role == 'advertiser'): ?>
                   <h2 class="text-white mt-3">Advertiser</h2>
                   <?php elseif(Auth::user()->role == 'publisher'): ?>
                   <h2 class="text-white mt-3">Publisher</h2>
                   <?php elseif(Auth::user()->role == 'admin'): ?>
                   <h2 class="text-white mt-3">Admin</h2>

                   <?php endif; ?>
               <?php endif; ?>
            </span>
        </a>
        <button type="button" class="btn btn-sm p-0 fs-20 header-item float-end btn-vertical-sm-hover"
            id="vertical-hover">
            <i class="ri-record-circle-line"></i>
        </button>
    </div>

    <div id="scrollbar">
        <div class="container-fluid">
            <div id="two-column-menu"></div>
            <ul class="navbar-nav" id="navbar-nav">
                <li class="menu-title"><span><?php echo app('translator')->get('translation.menu'); ?></span></li>

                <?php if(auth()->guard()->check()): ?>
                
                    <?php if(Auth::user()->role == 'publisher'): ?>
                        <!-- Publisher Menu Items -->
                        <li class="nav-item">
                            <a class="nav-link menu-link <?php echo e(request()->routeIs('publishers.dashboard') ? 'active' : ''); ?>"
                                href="<?php echo e(route('publishers.dashboard')); ?>">
                                <i class="fa fa-home" aria-hidden="true"></i>  <span>Home</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link menu-link <?php echo e(request()->routeIs('publishers.website') ? 'active' : ''); ?>"
                                href="<?php echo e(route('publishers.website')); ?>">
                                <i class="fa fa-list-alt" aria-hidden="true"></i><span>Website</span>
                            </a>
                        </li>
                        
                        <li class="nav-item">
                            <a class="nav-link menu-link"
                                href="">
                                <i class='bx bxs-analyse'></i><span>Sell</span>
                            </a>
                        </li>
                         
                         <li class="nav-item">
                            <a class="nav-link menu-link"
                                href="">
                                <i class="fa fa-google-wallet" aria-hidden="true"></i><span>Wallet</span>
                            </a>
                        </li>


                        <li class="nav-item">
                            <a class="nav-link menu-link <?php echo e(request()->routeIs('publishers.ContactSupport') ? 'active' : ''); ?>"
                                href="<?php echo e(route('publishers.ContactSupport')); ?>">
                                <i class="fa fa-life-ring" aria-hidden="true"></i> <span>Contact Support</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link menu-link <?php echo e(request()->routeIs('publishers.KYC') ? 'active' : ''); ?>"
                                href="<?php echo e(route('publishers.KYC')); ?>">
                                <i class="fa fa-yoast" aria-hidden="true"></i></i><span>KYC Application</span>
                            </a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link menu-link <?php echo e(request()->routeIs('publishers.ProfileSetting') ? 'active' : ''); ?>"
                                href="<?php echo e(route('publishers.ProfileSetting')); ?>">
                                <i class="fa fa-cog" aria-hidden="true"></i> <span>Profile Setting</span>
                            </a>
                        </li>

                          <!-- Membership Menu Item -->
                        
                        

                        <!-- Payments Menu Item ✨ -->
                        

                        <!-- NFT Marketplace Menu Item ✨ -->
                        

                        <!-- Support Tickets Menu Item ✨ -->
                        

                        <!-- Chat Menu Item ✨-->
                        
                        
                    <?php elseif(Auth::user()->role == 'advertiser'): ?>
                        <!-- Advertiser Menu Items -->
                        
                         <!-- Chat Menu Item ✨-->

                        <li class="nav-item">
                            <a class="nav-link menu-link <?php echo e(request()->routeIs('advertiser.dashboard') ? 'active' : ''); ?>"
                                href="<?php echo e(route('advertiser.dashboard')); ?>">
                                <i class="fa fa-home" aria-hidden="true"></i> <span>Home</span>
                            </a>
                        </li>
                        
                        <li class="nav-item">
                            <a class="nav-link menu-link <?php echo e(request()->routeIs('advertiser.project.list') ? 'active' : ''); ?>"
                                href="<?php echo e(route('advertiser.project.list')); ?>">
                                <i class="fa fa-list-ul" aria-hidden="true"></i><span>My Projects</span>
                            </a>
                        </li>
                        
                        <li class="nav-item">
                            <a class="nav-link menu-link <?php echo e(request()->routeIs('advertiser.webs.list') ? 'active' : ''); ?>"
                                href="<?php echo e(route('advertiser.webs.list')); ?>">
                                <i class="fa fa-list-ul" aria-hidden="true"></i><span>Websites</span>
                            </a>
                        </li>
                        
                        
                        
                        
                        <li class="nav-item">
                            <a class="nav-link menu-link "
                                href="<?php echo e(route('advertiser.purchase.webList')); ?>">
                                <i class="fa fa-money" aria-hidden="true"></i><span>Purchase</span>
                            </a>
                        </li>
                        
                        <li class="nav-item">
                            <a class="nav-link menu-link <?php echo e(request()->routeIs('advertiser.wallet') ? 'active' : ''); ?>"
                                href="<?php echo e(route('advertiser.wallet')); ?>">
                                <i class="fa fa-google-wallet" aria-hidden="true"></i><span>Wallet</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link menu-link <?php echo e(request()->routeIs('advertiser.favourireWeb') ? 'active' : ''); ?>"
                                href="<?php echo e(route('advertiser.favourireWeb')); ?>">
                                <i class="fa fa-gratipay" aria-hidden="true"></i><span>Favourite</span>
                            </a>
                        </li>


                        <li class="nav-item">
                            <a class="nav-link menu-link <?php echo e(request()->routeIs('advertiser.ProfileSetting') ? 'active' : ''); ?>"
                                href="<?php echo e(route('advertiser.ProfileSetting')); ?>">
                                <i class="fa fa-cog" aria-hidden="true"></i><span>Profile Setting</span>
                            </a>
                        </li>
                        <?php elseif(Auth::user()->role == 'admin'): ?>
                        <li class="nav-item">
                            <a class="nav-link menu-link <?php echo e(request()->routeIs('admin.dashboard') ? 'active' : ''); ?>"
                                href="<?php echo e(route('admin.dashboard')); ?>">
                                <i class="fa fa-home" aria-hidden="true"></i> <span>Home</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link menu-link <?php echo e(request()->routeIs('admin.user.list') ? 'active' : ''); ?>"
                                href="<?php echo e(route('admin.user.list')); ?>">
                                <i class="fa fa-user-plus" aria-hidden="true"></i> <span>Users</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="#sidebarProjects" class="nav-link <?php echo e(request()->routeIs(['admin.websites.pending', 'admin.website.list', 'admin.websites.approve', 'admin.website.rejected']) ? 'active' : ''); ?> " data-bs-toggle="collapse" role="button" aria-expanded="false" aria-controls="sidebarProjects">
                                <i class="fa fa-external-link" aria-hidden="true"></i> <span>Websites</span>
                            </a>
                            <div class="collapse menu-dropdown" id="sidebarProjects">
                                <ul class="nav nav-sm flex-column">
                                    <li class="nav-item <?php echo e(request()->routeIs('admin.website.list') ? 'active' : ''); ?>">
                                        <a href="<?php echo e(route('admin.website.list')); ?>" class="nav-link">List</a>
                                    </li>
                                    <li class="nav-item <?php echo e(request()->routeIs('admin.websites.pending') ? 'active' : ''); ?>">
                                        <a href="<?php echo e(route('admin.websites.pending')); ?>" class="nav-link">Pending</a>
                                    </li>

                                    <li class="nav-item <?php echo e(request()->routeIs('admin.websites.approve') ? 'active' : ''); ?>">
                                        <a href="<?php echo e(route('admin.websites.approve')); ?>" class="nav-link">Approve</a>
                                    </li>
                                    <li class="nav-item <?php echo e(request()->routeIs('admin.website.rejected') ? 'active' : ''); ?>">
                                        <a href="<?php echo e(route('admin.website.rejected')); ?> "class="nav-link">Rejected</a>
                                    </li>

                                </ul>
                            </div>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link menu-link <?php echo e(request()->routeIs('admin.ProfileSetting') ? 'active' : ''); ?>"
                                href="<?php echo e(route('admin.ProfileSetting')); ?>">
                                <i class="fa fa-cog" aria-hidden="true"></i> <span>Profile Setting</span>
                            </a>
                        </li>

                    <?php endif; ?>

                <?php endif; ?>
            </ul>
        </div>
        <!-- Sidebar -->
    </div>
    <div class="sidebar-background"></div>
</div>
<!-- Left Sidebar End -->
<!-- Vertical Overlay-->
<div class="vertical-overlay"></div>
<?php /**PATH D:\BS.IT_Material\Hidden-logics\laravel\BackLinks\resources\views/components/sidebar.blade.php ENDPATH**/ ?>