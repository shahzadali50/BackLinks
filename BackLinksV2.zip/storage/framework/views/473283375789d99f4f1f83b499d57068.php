<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" data-layout="vertical" data-topbar="light"
    data-sidebar="dark" data-sidebar-size="lg" data-sidebar-image="none" data-preloader="disable">

<head>
    <meta charset="utf-8" />
    <title><?php echo $__env->yieldContent('title'); ?> </title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="Premium Multipurpose Admin & Dashboard Template" name="description" />
    <meta content="Themesbrand" name="author" />
    <!-- App favicon -->
    <link rel="shortcut icon" href="<?php echo e(URL::asset('build/images/favicon.ico')); ?>">

    
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    
    
    <?php if (isset($component)) { $__componentOriginale7e538c3076c7cf5dc291c8995a8b28d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale7e538c3076c7cf5dc291c8995a8b28d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.head-css','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('head-css'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale7e538c3076c7cf5dc291c8995a8b28d)): ?>
<?php $attributes = $__attributesOriginale7e538c3076c7cf5dc291c8995a8b28d; ?>
<?php unset($__attributesOriginale7e538c3076c7cf5dc291c8995a8b28d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale7e538c3076c7cf5dc291c8995a8b28d)): ?>
<?php $component = $__componentOriginale7e538c3076c7cf5dc291c8995a8b28d; ?>
<?php unset($__componentOriginale7e538c3076c7cf5dc291c8995a8b28d); ?>
<?php endif; ?>

</head>


<body>
    <!-- Begin page -->
    <div id="layout-wrapper">
        
        <?php if (isset($component)) { $__componentOriginal7f27d4f21ff184c2d29c20efafbd7387 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7f27d4f21ff184c2d29c20efafbd7387 = $attributes; } ?>
<?php $component = App\View\Components\Topbar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('topbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Topbar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7f27d4f21ff184c2d29c20efafbd7387)): ?>
<?php $attributes = $__attributesOriginal7f27d4f21ff184c2d29c20efafbd7387; ?>
<?php unset($__attributesOriginal7f27d4f21ff184c2d29c20efafbd7387); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7f27d4f21ff184c2d29c20efafbd7387)): ?>
<?php $component = $__componentOriginal7f27d4f21ff184c2d29c20efafbd7387; ?>
<?php unset($__componentOriginal7f27d4f21ff184c2d29c20efafbd7387); ?>
<?php endif; ?>
        
        <?php if (isset($component)) { $__componentOriginal2880b66d47486b4bfeaf519598a469d6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2880b66d47486b4bfeaf519598a469d6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sidebar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2880b66d47486b4bfeaf519598a469d6)): ?>
<?php $attributes = $__attributesOriginal2880b66d47486b4bfeaf519598a469d6; ?>
<?php unset($__attributesOriginal2880b66d47486b4bfeaf519598a469d6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2880b66d47486b4bfeaf519598a469d6)): ?>
<?php $component = $__componentOriginal2880b66d47486b4bfeaf519598a469d6; ?>
<?php unset($__componentOriginal2880b66d47486b4bfeaf519598a469d6); ?>
<?php endif; ?>


        <div class="main-content">
            <div class="page-content">
                <div class="container-fluid">
                    <?php echo $__env->yieldContent('content'); ?>
                </div>

            </div>

        </div>

    </div>

    <?php if (isset($component)) { $__componentOriginalc8adca3b2cd1752cd49c812ddcd05b93 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc8adca3b2cd1752cd49c812ddcd05b93 = $attributes; } ?>
<?php $component = App\View\Components\Customizer::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('customizer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Customizer::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc8adca3b2cd1752cd49c812ddcd05b93)): ?>
<?php $attributes = $__attributesOriginalc8adca3b2cd1752cd49c812ddcd05b93; ?>
<?php unset($__attributesOriginalc8adca3b2cd1752cd49c812ddcd05b93); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc8adca3b2cd1752cd49c812ddcd05b93)): ?>
<?php $component = $__componentOriginalc8adca3b2cd1752cd49c812ddcd05b93; ?>
<?php unset($__componentOriginalc8adca3b2cd1752cd49c812ddcd05b93); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal31cb59423ba1f759026ebe11d6ad323d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal31cb59423ba1f759026ebe11d6ad323d = $attributes; } ?>
<?php $component = App\View\Components\Foot::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('foot'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Foot::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal31cb59423ba1f759026ebe11d6ad323d)): ?>
<?php $attributes = $__attributesOriginal31cb59423ba1f759026ebe11d6ad323d; ?>
<?php unset($__attributesOriginal31cb59423ba1f759026ebe11d6ad323d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal31cb59423ba1f759026ebe11d6ad323d)): ?>
<?php $component = $__componentOriginal31cb59423ba1f759026ebe11d6ad323d; ?>
<?php unset($__componentOriginal31cb59423ba1f759026ebe11d6ad323d); ?>
<?php endif; ?>

</body>

</html>
<?php /**PATH D:\BS.IT_Material\Hidden-logics\laravel\BackLinks\resources\views/layouts/app.blade.php ENDPATH**/ ?>